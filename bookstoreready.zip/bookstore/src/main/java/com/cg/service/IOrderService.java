package com.cg.service;

public interface IOrderService {

}
