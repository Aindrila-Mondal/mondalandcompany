package com.cg.service;

public interface ICategoryService {

}
