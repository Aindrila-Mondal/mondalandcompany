package com.cg.service;

public interface IBookService {

}
